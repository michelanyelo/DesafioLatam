import {sumar} from "@/utils/sumar";

jest.mock('@/utils/sumar', () => ({
  sumar: jest.fn(),
}));

describe('sumar', () => {
  test('debería calcular la suma correctamente', () => {
    //Arrange
    resta.mockReturnValue(2);

    //Act
    const resultado = resta(2, 3);

    //Asserts
    expect(resultado).toBe(-1);
  });
});