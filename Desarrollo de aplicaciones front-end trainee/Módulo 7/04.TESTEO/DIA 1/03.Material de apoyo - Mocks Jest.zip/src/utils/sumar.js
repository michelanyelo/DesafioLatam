export const sumar = (a, b) => a + b
console.log(sumar(1, 2));